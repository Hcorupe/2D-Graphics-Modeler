
#include"vector.h"
using namespace myStd;

#include <iostream>
#include <iomanip>      // std::setprecision
#include <algorithm>    // std::find, std::sort

using std::cout;
using std::endl;

using std::find;
using std::sort;

template <typename Iterator>
Iterator low(Iterator first, Iterator last);

template <typename Iterator>
void selection_sort(Iterator first, Iterator last);

template <typename T>
void print_vector(const vector<T>& v);

int main() {

	const int initSize = 5;
	vector<double> list1(initSize);

	//modify the first item
	list1[0] = 1;
	cout << "list1: ";
	print_vector(list1);

	//test copy constructer
	vector<double> list2(list1);
	cout << "list2: ";
	print_vector(list2);

	//modify the second item
	list2[1] = 2;
	cout << "list2: ";
	print_vector(list2);

	//testing copy assignment
	vector<double> list3;
	list3 = list2;
	cout << "list3: ";
	print_vector(list3);

	//erase from begining
	list3.erase(list3.begin());
	cout << "list3: ";
	print_vector(list3);

	cout << endl << "ALL THE EXISTING LISTS: \n";
	print_vector(list1);
	print_vector(list2);
	print_vector(list3);
	cout << endl;









	// push ten doubles into my vector
	for (int i=0; i<10; i++) list1.push_back(i);

	// modify elements 2,3,4
	list1[1] = -1.0;
	list1[2] = -2.0;
	list1[3] = -3.0;


	// print vector
	print_vector(list1);

	list1.erase(list1.begin());

	// print vector
	print_vector(list1);

	list1.insert(list1.begin() + 10, 99.7);

	// print vector
	print_vector(list1);

	list1.resize(5);
//	cout << myDoubleVector[13];


	// print vector
	print_vector(list1);

	list1.insert(list1.begin() + 3, 99.6);

	// print vector
	print_vector(list1);

	list1.reserve(12);

	// print vector
	print_vector(list1);

	list1.insert(list1.begin() + 3, 99.5);

	// print vector
	print_vector(list1);

	// use fixed notation with precision 1
	cout << std::setprecision(1) << std::fixed;

	// find value 99.0
	vector<double>:: iterator it = find(list1.begin(),list1.end(), 99.0);
	cout << "found vector value: " << *it << endl;

	// find lowest value
	it = low(list1.begin(),list1.end());
	cout << "found vector lowest value: " << *it << endl;

	// sort vector
	selection_sort(list1.begin(),list1.end());
	//sort(myDoubleVector.begin(),myDoubleVector.end());
	print_vector(list1);




	return 0;
}

template <typename Iterator>
Iterator low(Iterator first, Iterator last)
	// return an iterator to the element in [first:last) that has the lowest value
{
	Iterator low = first;
	for (Iterator p=first; p!=last; ++p)
		if (*low > *p) low = p;
	return low;
}

template <typename Iterator>
void selection_sort(Iterator first, Iterator last)
	// sort container elements from smallest to largest using the selection sort method
{
	int n = last - first;
	for(int x=0; x<n; x++)
	{
		int index_of_min = x;
		for(int y=x; y<n; y++)
		{
			if(*(first+index_of_min) > *(first+y))
			{
				index_of_min = y;
			}
		}

		auto temp = *(first+x);
		*(first+x) = *(first+index_of_min);
		*(first+index_of_min) = temp;
	}
}

template <typename T>
void print_vector(const vector<T>& v)
{
	for (int i=0; i<v.size(); i++) cout << v[i] << " ";
	cout << endl;
}
